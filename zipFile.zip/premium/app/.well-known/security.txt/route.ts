// RFC 9116 — security.txt
// https://www.rfc-editor.org/rfc/rfc9116
// Served at /.well-known/security.txt
import { SITE } from "@/lib/site-data"

export const dynamic = "force-static"

export function GET() {
  // Expires one year from build time.
  const expires = new Date()
  expires.setFullYear(expires.getFullYear() + 1)

  const body = [
    `Contact: mailto:security@${SITE.domain.replace(/^https?:\/\//, "")}`,
    `Contact: mailto:${SITE.email}`,
    `Expires: ${expires.toISOString()}`,
    `Preferred-Languages: en`,
    `Canonical: ${SITE.domain}/.well-known/security.txt`,
    `Policy: ${SITE.domain}/security-policy`,
    "",
  ].join("\n")

  return new Response(body, {
    status: 200,
    headers: {
      "Content-Type": "text/plain; charset=utf-8",
      "Cache-Control": "public, max-age=86400",
    },
  })
}
