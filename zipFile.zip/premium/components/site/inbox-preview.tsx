"use client"

import { useEffect, useState } from "react"
import { motion, AnimatePresence, useReducedMotion } from "framer-motion"
import { CheckCheck, CornerUpLeft, Mail, Sparkles, Star } from "lucide-react"

/**
 * Animated inbox preview — Gmail-style.
 * Sequence (12s loop):
 *   t=0   : sent indicator
 *   t=2.5s: prospect opens (read receipt)
 *   t=5s  : reply lands with green badge
 *   t=10s : restart fade
 */
export function InboxPreview() {
  const reduce = useReducedMotion()
  const [stage, setStage] = useState<0 | 1 | 2>(0)

  useEffect(() => {
    if (reduce) {
      setStage(2)
      return
    }
    const t1 = setTimeout(() => setStage(1), 2500)
    const t2 = setTimeout(() => setStage(2), 5000)
    const t3 = setInterval(() => {
      setStage(0)
      setTimeout(() => setStage(1), 2500)
      setTimeout(() => setStage(2), 5000)
    }, 12000)
    return () => {
      clearTimeout(t1)
      clearTimeout(t2)
      clearInterval(t3)
    }
  }, [reduce])

  return (
    <div className="relative w-full max-w-[480px]">
      {/* Glow halo */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -inset-12 -z-10 rounded-[3rem] opacity-50 blur-3xl"
        style={{
          background:
            "radial-gradient(ellipse at center, oklch(0.55 0.24 295 / 0.25), transparent 70%)",
        }}
      />

      {/* Main inbox card */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5, duration: 0.7, ease: [0.22, 1, 0.36, 1] as const }}
        className={`glass-card relative overflow-hidden rounded-2xl ${reduce ? "" : "inbox-float"}`}
        style={{ boxShadow: "var(--shadow-2xl)" }}
      >
        {/* Window chrome */}
        <div className="flex items-center justify-between border-b border-ink-08 bg-cream/50 px-4 py-2.5">
          <div className="flex items-center gap-1.5">
            <span className="size-2.5 rounded-full bg-[#FF5F57]" />
            <span className="size-2.5 rounded-full bg-[#FEBC2E]" />
            <span className="size-2.5 rounded-full bg-[#28C840]" />
          </div>
          <div className="flex items-center gap-1.5 rounded-md bg-background/60 px-2.5 py-1 text-[10.5px] font-medium tabular text-ink-60">
            <Mail className="size-3" strokeWidth={2} />
            Inbox · sarah@helio.ai
          </div>
          <div className="size-2.5" />
        </div>

        {/* Email list */}
        <div className="divide-y divide-ink-08">
          {/* The campaign email */}
          <div className="flex gap-3 p-4 transition-colors hover:bg-cream/30">
            <div className="grid size-9 shrink-0 place-items-center rounded-full bg-gradient-to-br from-vibrant-purple to-electric-blue text-[12px] font-semibold text-white">
              FO
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <span className="truncate text-[13px] font-semibold text-ink">
                  Marcus from FinalOutreach
                </span>
                <span className="shrink-0 text-[11px] tabular text-ink-40">
                  9:14 AM
                </span>
              </div>
              <p className="mt-0.5 truncate text-[12.5px] text-ink-60">
                Saw your post on attribution — quick idea
              </p>
              <p className="mt-1.5 line-clamp-2 text-[12px] leading-[1.5] text-ink-40">
                Hi Sarah, caught your LinkedIn post on multi-touch attribution
                last week — the budget bleed point hit a nerve here…
              </p>
              <div className="mt-2 flex items-center gap-2">
                <AnimatePresence>
                  {stage >= 1 && (
                    <motion.span
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.3 }}
                      className="inline-flex items-center gap-1 rounded-full bg-emerald/10 px-2 py-0.5 text-[10px] font-medium text-emerald"
                    >
                      <CheckCheck className="size-3" strokeWidth={2.4} />
                      Opened · 9:18 AM
                    </motion.span>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>

          {/* The reply (only after stage 2) */}
          <AnimatePresence>
            {stage >= 2 && (
              <motion.div
                key="reply"
                initial={{ opacity: 0, y: 16, scale: 0.96 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] as const }}
                className="relative flex gap-3 bg-gradient-to-r from-emerald/[0.08] to-transparent p-4"
              >
                <div className="grid size-9 shrink-0 place-items-center rounded-full bg-gradient-to-br from-emerald to-emerald-bright text-[12px] font-semibold text-white">
                  SC
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center justify-between gap-2">
                    <span className="truncate text-[13px] font-semibold text-ink">
                      Sarah Chen — VP Marketing
                    </span>
                    <span className="shrink-0 inline-flex items-center gap-1 rounded-full bg-emerald/15 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-emerald">
                      <Sparkles className="size-2.5" strokeWidth={2.4} />
                      Reply
                    </span>
                  </div>
                  <p className="mt-0.5 truncate text-[12.5px] font-medium text-ink">
                    Re: Saw your post on attribution
                  </p>
                  <p className="mt-1.5 line-clamp-2 text-[12px] leading-[1.5] text-ink-60">
                    Yes — would love to see that teardown. Free Thursday at 2pm
                    PST? Happy to chat properly.
                  </p>
                  <div className="mt-2 flex items-center gap-1.5 text-[11px] text-emerald">
                    <CornerUpLeft className="size-3" strokeWidth={2.4} />
                    <span className="font-medium">
                      Meeting booked · Thursday 2:00 PM
                    </span>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Footer stats */}
        <div className="flex items-center justify-between gap-4 border-t border-ink-08 bg-cream/40 px-4 py-2.5 text-[11px] text-ink-60">
          <span className="inline-flex items-center gap-1.5">
            <span className="size-1.5 rounded-full bg-emerald pulse-dot" />
            <span className="font-medium tabular">Live campaign</span>
          </span>
          <div className="flex items-center gap-3 tabular">
            <span>
              Reply rate{" "}
              <span className="font-semibold text-emerald">21%</span>
            </span>
            <span className="text-ink-20">·</span>
            <span>
              Booked{" "}
              <span className="font-semibold text-vibrant-purple">+1</span>
            </span>
          </div>
        </div>
      </motion.div>

      {/* Floating side badges */}
      <motion.div
        initial={{ opacity: 0, x: -20, y: 20 }}
        animate={{ opacity: 1, x: 0, y: 0 }}
        transition={{ delay: 1.2, duration: 0.6 }}
        className="glass-card absolute -bottom-6 -left-8 hidden items-center gap-2 rounded-xl px-3 py-2 sm:flex"
        style={{ boxShadow: "var(--shadow-lg)" }}
      >
        <div className="grid size-7 place-items-center rounded-lg bg-gradient-to-br from-emerald/20 to-emerald-bright/10">
          <Star className="size-3.5 text-emerald" strokeWidth={2.2} />
        </div>
        <div>
          <div className="text-[10px] font-medium uppercase tracking-wider text-ink-40">
            Deliverability
          </div>
          <div className="text-[12px] font-semibold tabular text-ink">
            98.7% inbox
          </div>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, x: 20, y: -20 }}
        animate={{ opacity: 1, x: 0, y: 0 }}
        transition={{ delay: 1.4, duration: 0.6 }}
        className="glass-card absolute -top-5 -right-6 hidden items-center gap-2 rounded-xl px-3 py-2 sm:flex"
        style={{ boxShadow: "var(--shadow-lg)" }}
      >
        <div className="grid size-7 place-items-center rounded-lg bg-gradient-to-br from-vibrant-purple/20 to-electric-blue/10">
          <Sparkles className="size-3.5 text-vibrant-purple" strokeWidth={2.2} />
        </div>
        <div>
          <div className="text-[10px] font-medium uppercase tracking-wider text-ink-40">
            This week
          </div>
          <div className="text-[12px] font-semibold tabular text-ink">
            +23 meetings
          </div>
        </div>
      </motion.div>
    </div>
  )
}
