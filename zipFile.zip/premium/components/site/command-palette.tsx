"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Command } from "cmdk"
import {
  ArrowRight,
  Briefcase,
  Calendar,
  Compass,
  FileText,
  Home,
  Layers,
  MessageCircle,
  Search,
  Sparkles,
  TrendingUp,
} from "lucide-react"
import { SERVICES, INDUSTRIES } from "@/lib/site-data"

export function CommandPalette() {
  const [open, setOpen] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault()
        setOpen((o) => !o)
      }
      if (e.key === "Escape") setOpen(false)
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [])

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : ""
    return () => {
      document.body.style.overflow = ""
    }
  }, [open])

  const go = (href: string) => {
    setOpen(false)
    router.push(href)
  }

  if (!open) return null

  return (
    <div
      className="fixed inset-0 z-[100] grid place-items-start justify-center px-4 pt-[10vh]"
      onClick={() => setOpen(false)}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/40 backdrop-blur-md" />

      {/* Palette */}
      <div
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-xl overflow-hidden rounded-2xl border border-ink-08 bg-background shadow-premium-2xl"
      >
        <Command label="Command palette" loop>
          <div className="flex items-center gap-3 border-b border-ink-08 px-4">
            <Search className="size-4 text-ink-40" strokeWidth={2} />
            <Command.Input
              placeholder="Search services, pages, or actions…"
              className="flex-1 bg-transparent py-4 text-[14.5px] text-ink placeholder:text-ink-40 focus:outline-none"
            />
            <kbd className="rounded-md border border-ink-08 bg-cream px-2 py-0.5 font-mono text-[10.5px] text-ink-60">
              ESC
            </kbd>
          </div>

          <Command.List className="max-h-[60vh] overflow-y-auto p-2">
            <Command.Empty className="px-3 py-8 text-center text-[13px] text-ink-60">
              No results. Try "pricing" or "case studies".
            </Command.Empty>

            <Command.Group
              heading="Navigation"
              className="px-2 py-1.5 text-[10.5px] font-medium uppercase tracking-[0.10em] text-ink-40"
            >
              <Item icon={<Home className="size-4" />} onSelect={() => go("/")}>
                Home
              </Item>
              <Item
                icon={<Briefcase className="size-4" />}
                onSelect={() => go("/services")}
              >
                Services
              </Item>
              <Item
                icon={<Layers className="size-4" />}
                onSelect={() => go("/case-studies")}
              >
                Case studies
              </Item>
              <Item
                icon={<TrendingUp className="size-4" />}
                onSelect={() => go("/pricing")}
              >
                Pricing
              </Item>
              <Item
                icon={<Compass className="size-4" />}
                onSelect={() => go("/process")}
              >
                Process
              </Item>
              <Item
                icon={<FileText className="size-4" />}
                onSelect={() => go("/blog")}
              >
                Blog
              </Item>
              <Item
                icon={<Sparkles className="size-4" />}
                onSelect={() => go("/about")}
              >
                About
              </Item>
            </Command.Group>

            <Command.Group
              heading="Services"
              className="mt-2 px-2 py-1.5 text-[10.5px] font-medium uppercase tracking-[0.10em] text-ink-40"
            >
              {SERVICES.map((s) => (
                <Item
                  key={s.slug}
                  icon={<Briefcase className="size-4" />}
                  onSelect={() => go(`/services/${s.slug}`)}
                >
                  {s.shortTitle}
                </Item>
              ))}
            </Command.Group>

            <Command.Group
              heading="Industries"
              className="mt-2 px-2 py-1.5 text-[10.5px] font-medium uppercase tracking-[0.10em] text-ink-40"
            >
              {INDUSTRIES.slice(0, 8).map((i) => (
                <Item
                  key={i.slug}
                  icon={<Layers className="size-4" />}
                  onSelect={() => go(`/industries/${i.slug}`)}
                >
                  {i.name}
                </Item>
              ))}
            </Command.Group>

            <Command.Group
              heading="Actions"
              className="mt-2 px-2 py-1.5 text-[10.5px] font-medium uppercase tracking-[0.10em] text-ink-40"
            >
              <Item
                icon={<Calendar className="size-4 text-vibrant-purple" />}
                onSelect={() => go("/contact")}
                accent
              >
                Book a strategy call
              </Item>
              <Item
                icon={<MessageCircle className="size-4" />}
                onSelect={() => go("/contact")}
              >
                Contact us
              </Item>
            </Command.Group>
          </Command.List>

          <div className="flex items-center justify-between gap-3 border-t border-ink-08 bg-cream/50 px-4 py-2.5 text-[11px] text-ink-60">
            <div className="flex items-center gap-3">
              <span className="inline-flex items-center gap-1">
                <kbd className="rounded border border-ink-08 bg-background px-1 font-mono text-[10px]">
                  ↑↓
                </kbd>
                Navigate
              </span>
              <span className="inline-flex items-center gap-1">
                <kbd className="rounded border border-ink-08 bg-background px-1 font-mono text-[10px]">
                  ↵
                </kbd>
                Select
              </span>
            </div>
            <span className="font-mono">FinalOutreach</span>
          </div>
        </Command>
      </div>
    </div>
  )
}

function Item({
  icon,
  children,
  onSelect,
  accent,
}: {
  icon: React.ReactNode
  children: string
  onSelect: () => void
  accent?: boolean
}) {
  return (
    <Command.Item
      onSelect={onSelect}
      className={`group flex cursor-pointer items-center justify-between rounded-lg px-3 py-2.5 text-[13.5px] transition-colors data-[selected=true]:bg-cream ${
        accent ? "data-[selected=true]:bg-gradient-to-r data-[selected=true]:from-vibrant-purple/10 data-[selected=true]:to-electric-blue/10" : ""
      }`}
    >
      <span className="flex items-center gap-3 text-ink">
        <span className="text-ink-60">{icon}</span>
        {children}
      </span>
      <ArrowRight className="size-3.5 text-ink-40 opacity-0 transition-opacity group-data-[selected=true]:opacity-100" />
    </Command.Item>
  )
}
